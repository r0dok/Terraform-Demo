import boto3
import json
import os
import base64

# Initialize AWS resources
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

# Use default values if environment variables are not set
BUCKET_NAME = os.environ.get('BUCKET_NAME', 'file-storage-example-bucket')
TABLE_NAME = os.environ.get('TABLE_NAME', 'example_table')

def lambda_handler(event, context):
    try:
        # Input validation checks
        if 'body' not in event or 'headers' not in event:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid event object"})
            }
        
        file_content = event['body']
        file_name = event['headers'].get('filename')
        
        # Ensure file content is base64 encoded
        if file_content and event.get('isBase64Encoded'):
            file_content = base64.b64decode(file_content)
        
        # Check if file name is valid
        if not file_name or not isinstance(file_name, str):
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid filename"})
            }
        
        # Upload file to S3
        s3.put_object(Bucket=BUCKET_NAME, Key=file_name, Body=file_content)
        
        # Save filename to DynamoDB
        table = dynamodb.Table(TABLE_NAME)
        table.put_item(Item={"filename": file_name})
        
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "File uploaded successfully"})
        }
    except Exception as e:
        # Log exception and return a generic error message
        import logging
        logging.error(str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal Server Error"})
        }
